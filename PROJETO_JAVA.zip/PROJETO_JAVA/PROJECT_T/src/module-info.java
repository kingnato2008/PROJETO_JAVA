/**
 * 
 */
/**
 * 
 */
module PROJECT_T {
	requires java.naming;
}