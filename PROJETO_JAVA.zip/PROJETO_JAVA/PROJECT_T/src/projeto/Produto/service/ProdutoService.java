package projeto.Produto.service;

import projeto.Cliente.exceptions.models.InvalidCodeException;
import projeto.Cliente.exceptions.models.InvalidEmailException;
import projeto.Cliente.models.Cliente;
import projeto.Pessoa.exceptions.models.InvalidAgeException;
import projeto.Pessoa.exceptions.models.InvalidCpfException;
import projeto.Pessoa.exceptions.models.InvalidNameException;
import projeto.Pessoa.models.Pessoa;
import projeto.Produto.exceptions.models.InvalidDescriptionException;
import projeto.Produto.exceptions.models.InvalidIdException;
import projeto.Produto.exceptions.models.InvalidPriceException;
import projeto.Produto.models.Produto;
import projeto.Produto.utils.validator.ValidatorProduto;

import java.util.ArrayList;
import java.util.Scanner;
import java.util.Iterator;

public class ProdutoService extends Produto {

	// REGISTER PRODUCT
	public static void registerProduct(Scanner keyboard, ArrayList<Produto> list1)
			throws InvalidPriceException, InvalidDescriptionException, InvalidIdException {
		// REGISTER
		System.out.println("==============CADASTRO-DE-PRODUTOS==============");

		// CATEGORY
		System.out.println("Categoria: ");
		String categoryNewProduct = keyboard.nextLine();
		ValidatorProduto.validateDescription(categoryNewProduct);

		// TYPE
		System.out.println("Tipo: ");
		String typeNewProduct = keyboard.nextLine();
		ValidatorProduto.validateDescription(typeNewProduct);

		// ID
		System.out.println("ID: ");
		int idNewProduct = keyboard.nextInt();
		keyboard.nextLine();
		ValidatorProduto.validateId(list1, idNewProduct);

		// DESCRIPTION
		System.out.println("Descrição: ");
		String descriptionNewProduct = keyboard.nextLine();
		ValidatorProduto.validateDescription(descriptionNewProduct);

		// PRICE
		System.out.println("Preço: ");
		double priceNewProduct = keyboard.nextDouble();
		ValidatorProduto.validatePrice(priceNewProduct);

		// NEW PRODUCT
		Produto newProduct = new Produto(categoryNewProduct, typeNewProduct, descriptionNewProduct, idNewProduct,
				priceNewProduct);
		list1.add(newProduct);
	}

	// REGISTER PRODUCT WITH RETRY
	public static void registerProductWithRetry(ArrayList<Produto> list1, Scanner keyboard)
			throws InvalidIdException, InvalidPriceException, InvalidDescriptionException {
		boolean tf = false;
		do {
			try {
				registerProduct(keyboard, list1);
				tf = false;
			} catch (InvalidIdException e) {
				System.out.println(e.getMessage());
				tf = true;
			} catch (InvalidDescriptionException e) {
				System.out.println(e.getMessage());
				tf = true;
			} catch (InvalidPriceException e) {
				System.out.println(e.getMessage());
				tf = true;
			}
		} while (tf == true);
	}

	// SHOW ALL PRODUCTS
	public static void viewRecords(ArrayList<Produto> list1) {
		for (Produto p : list1) {
			System.out.println(p);
		}
	}

	// DELETE PRODUCT
	public static void deleteProduct(ArrayList<Produto> list1, Scanner keyboard) {
		viewRecords(list1);

		System.out.println("\nID do produto que deseja excluir: ");
		int idE = keyboard.nextInt();
		keyboard.nextLine();

		findDeleteProduct(list1, idE);
	}

	// FIND PRODUCT
	public static void findDeleteProduct(ArrayList<Produto> list1, int idE) {
		Iterator<Produto> iterator = list1.iterator();

		while (iterator.hasNext()) {
			Produto p = iterator.next();

			if (((Integer) p.getId()).equals(idE)) {
				iterator.remove();
				System.out.println("\nProduto removido com sucesso!");
				break;
			}
		}
	}


		public static void searchProduct(ArrayList<Produto> list1, Scanner keyboard){
			System.out.println("\n==================PESQUISA DE PRODUTO==================\n");
			System.out.println("Digite:");
			System.out.println("D para buscar pela descrição.");
			System.out.println("I para buscar por ID.");
			System.out.println("P para buscar por preço.");

			// Ler a entrada do usuário uma vez
			String choice = keyboard.nextLine().trim().toLowerCase();

			if(choice.equals("d")){
				System.out.println("Digite o nome do produto a ser buscado:");
				String description = keyboard.nextLine().trim();
				boolean found = false;
				for(Produto p : list1){
					if(p.getDescription().equalsIgnoreCase(description)){
						p.viewData();
						found = true;
						break; // Encerra o loop assim que encontrar o produto
					}
				}
				if (!found) {
					System.out.println("Produto não encontrado.");
				}
			}

			else if(choice.equals("i")){
				System.out.println("Digite o ID do produto a ser buscado:");
				int id = keyboard.nextInt();
				boolean found = false;
				for(Produto p : list1){
					if(p.getId() == id){
						p.viewData();
						found = true;
						break; // Encerra o loop assim que encontrar o produto
					}
				}
				if (!found) {
					System.out.println("Produto não encontrado.");
				}
			}

			else if(choice.equals("p")){
				System.out.println("Digite o preço do produto a ser buscado:");
				double price = keyboard.nextDouble();
				boolean found = false;
				for(Produto p : list1){
					if(p.getPrice() == price){
						p.viewData();
						found = true;
						break; // Encerra o loop assim que encontrar o produto
					}
				}
				if (!found) {
					System.out.println("Produto não encontrado.");
				}
			}

			else{
				System.out.println("Tecla inválida.");
			}
		}

	public static void mostExpensive(ArrayList<Produto> list1) {
		Produto moreExpensive = list1.get(0);
		for (Produto p : list1) {
			if (p.getPrice() > moreExpensive.getPrice()) {
				moreExpensive = p;
			}
		}
		moreExpensive.viewData();
	}

	public static void lessExpensive(ArrayList<Produto> list1) {
		Produto lessPrice = list1.get(0);
		for (Produto p : list1) {
			if (p.getPrice() < lessPrice.getPrice()) {
				lessPrice = p;
			}
		}
		lessPrice.viewData();
	}

	public static double averagePrice(ArrayList<Produto> list1) {
		if (list1.isEmpty()) {
			return 0;
		}
		double sumPrice = 0;
		for (Produto p : list1) {
			sumPrice += p.getPrice();
		}
		return sumPrice / list1.size();
	}

	public static int aboveAverage(ArrayList<Produto> list1) {
		double media = averagePrice(list1);
		int count = 0;
		for (Produto p : list1) {
			if (p.getPrice() > media) {
				count++;
			}
		}
		return count;
	}

}


