package projeto.Pessoa.interfaces;

public interface IPessoa {

	public String viewData();
}
